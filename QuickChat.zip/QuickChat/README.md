# QuickChat (Part 2: Sending Messages)

A C# (.NET 8) console app. The user logs in, sets how many messages to enter, then sends, stores or disregards each message.

## Requirements

- .NET 8 SDK, or Visual Studio 2022 with .NET 8 support

## Run

    dotnet run --project QuickChat

## Test

    dotnet test QuickChat.Tests

## Layout

- `QuickChat/Program.cs` contains the menu and the message flow.
- `QuickChat/Message.cs` contains the checks, the message hash and the Send, Disregard and Store choices.
- `QuickChat/MessageLog.cs` tracks sent messages, the total and unique message IDs.
- `QuickChat/MessageStore.cs` saves "Store" messages to `stored_messages.json`.
- `QuickChat/Login.cs` is a placeholder login that must be replaced with your Part 1 login.
- `QuickChat.Tests/` contains the unit tests, which GitHub Actions runs on every push.

## Before submitting

- Replace the placeholder login in `Login.cs` with your Part 1 login.
- Work on a feature branch, for example `git checkout -b feature/sending-messages`, and merge to `main` only when the tests pass.
